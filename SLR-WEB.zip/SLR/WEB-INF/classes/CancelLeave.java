package com;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
public class CancelLeave extends HttpServlet {
public void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
	String id=request.getParameter("t1").trim();
	String date=request.getParameter("t2").trim();
	try{
		String path = getServletContext().getRealPath("/")+"WEB-INF/leave.xlsx";
		File file = new File(path);
		String msg = SaveLeave.cancelLeave(file,id,date);
		if(msg.equals("success")){
			RequestDispatcher rd=request.getRequestDispatcher("CancelLeave.jsp?t1="+id+" leave cancelled successfully");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd=request.getRequestDispatcher("CancelLeave.jsp?t1=Error in cancelling leave");
			rd.forward(request, response);
		}
	}catch(Exception e){
		e.printStackTrace();
	}
}

}
