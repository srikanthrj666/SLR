package com;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import java.sql.Date;
public class GenerateData{
	static String[] name = {"Amit","Lokesh","John","Brian"};
	static int[] id = {111,222,3333,4444}; 
public static void main(String args[])throws Exception{
	java.util.Date d1 = new java.util.Date();
	java.sql.Date d2 = new java.sql.Date(d1.getTime());
	int k = 1;
	id = DBCon.getEid();
	for(int i=1;i<=30;i++){
		Map<String, Object[]> data = new TreeMap<String, Object[]>();
		//data.put("1", new Object[] {"ID", "Date", "In","Out"});
		for(int j=0;j<id.length;j++){
			data.put(Integer.toString(k), new Object[] {id[j],d2,"09:00:00","06:00:00"});
			k = k + 1;
		}
		save(d2.toString(),data);
		java.sql.Date current = createDate(d2);
		d2 = current;
		k = 1;
	}
}
public static  java.sql.Date createDate(java.sql.Date d1){
	long time = d1.getTime() + (1000 * 60 * 60 * 24);
	return new java.sql.Date(time);
}
public static void save(String date,Map<String, Object[]> data){
	XSSFWorkbook workbook = new XSSFWorkbook(); 
	XSSFSheet sheet = workbook.createSheet("Employee Data");
	CreationHelper createHelper = workbook.getCreationHelper();
	CellStyle cellStyle = workbook.createCellStyle();
    cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));
	Set<String> keyset = data.keySet();
	int rownum = 0;
	for(String key : keyset){
		Row row = sheet.createRow(rownum++);
		Object [] objArr = data.get(key);
		int cellnum = 0;
		for(Object obj : objArr){
			Cell cell = row.createCell(cellnum++);
			if(obj instanceof java.sql.Date){
				cell.setCellValue((java.sql.Date)obj);
				cell.setCellStyle(cellStyle);
			}
			else if(obj instanceof String){
				cell.setCellValue((String)obj);
			}
			else if(obj instanceof Integer){
				cell.setCellValue((Integer)obj);
			}
		}
	}
	try{
		FileOutputStream out = new FileOutputStream(new File("dataset/"+date+".xlsx"));
		workbook.write(out);
		out.close();
	}catch(Exception e){
		e.printStackTrace();
	}	
}
}