package com;
import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Calendar;
import java.util.Map;
import java.util.Set;
import java.util.LinkedHashMap;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
public class CalculateLeave{
	static ArrayList<Leave> leave = new ArrayList<Leave>();
	static java.sql.Date last = null;
	static HashMap<Integer,java.sql.Date> map = new HashMap<Integer,java.sql.Date>();
	static Map<String, Object[]> mergedata = new LinkedHashMap<String, Object[]>();
	static int index = 1;
	public static HashMap<String,ArrayList<String>> empdata = new HashMap<String,ArrayList<String>>();
public static void readLeaveExcel(String path){
	try{
		leave.clear();
		empdata.clear();
		FileInputStream file = new FileInputStream(new File(path));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();
		while(rowIterator.hasNext()){
			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			Leave obj = new Leave();
			boolean flag = false;
			while(cellIterator.hasNext()){
				Cell cell = cellIterator.next();
				switch(cell.getCellType()){
					case Cell.CELL_TYPE_NUMERIC:{
						if(HSSFDateUtil.isCellDateFormatted(cell)){
							double dv = cell.getNumericCellValue();
							if(cell.getColumnIndex() == 3){
								java.util.Date date = HSSFDateUtil.getJavaDate(dv);
								java.sql.Date dd = new java.sql.Date(date.getTime());
								obj.setStart(dd);
							}
							if(cell.getColumnIndex() == 4){
								java.util.Date date = HSSFDateUtil.getJavaDate(dv);
								java.sql.Date dd = new java.sql.Date(date.getTime());
								obj.setEnd(dd);
							}
						}else{
							obj.setID((int)cell.getNumericCellValue());
						}
						break;
					}
					case Cell.CELL_TYPE_STRING:{
						if(cell.getColumnIndex() == 1){
							obj.setReason(cell.getStringCellValue());
							if(obj.getReason().trim().length() > 0)
								flag = true;
						}
						if(cell.getColumnIndex() == 5){
							obj.setStatus(cell.getStringCellValue());
						}
						break;
					}
				}
			}
			if(flag && obj.getStatus().equals("Confirmed"))
				leave.add(obj);
		}
		file.close();
		System.out.println(leave.size());
	}catch(Exception e){
		e.printStackTrace();
	}
}
public static void readAttendedExcel(String path){
	try{
		map.clear();
		mergedata.clear();
		File fi = new File(path);
		File list[] = fi.listFiles();
		for(int i=0;i<list.length;i++){
			FileInputStream file = new FileInputStream(list[i]);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = sheet.iterator();
			//map.clear();
			while(rowIterator.hasNext()){
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				int id = 0;
				java.sql.Date date = null;
				while(cellIterator.hasNext()){
					Cell cell = cellIterator.next();
					switch(cell.getCellType()){
						case Cell.CELL_TYPE_NUMERIC:{
							if(HSSFDateUtil.isCellDateFormatted(cell)){
								double dv = cell.getNumericCellValue();
								if(cell.getColumnIndex() == 1){
									java.util.Date date1 = HSSFDateUtil.getJavaDate(dv);
									java.sql.Date dd = new java.sql.Date(date1.getTime());
									date = dd;
								}
							}else{
								id = (int)cell.getNumericCellValue();
							}
							break;
						}
					}
				}
				if(id != 0){
					merge(id,date);
				}
			}
			file.close();
		}
	}catch(Exception e){
		e.printStackTrace();
	}
}
public static void merge(int id,java.sql.Date current){
	Integer data = Integer.valueOf(id);
	if(!map.containsKey(data)){
		map.put(data,current);
		mergedata.put(Integer.toString(index), new Object[] {id,current,""});
		add(id,current.toString(),"");
		index = index + 1;
	}else{
		last = map.get(data);
		int days = days(last,current);
		if(days > 1){
			last = createDate(last);
			addDays(last,current,id);
		}
		map.put(data,current);
		add(id,current.toString(),"");
		mergedata.put(Integer.toString(index), new Object[] {id,current,""});
		index = index + 1;
	}
}
public static void addDays(java.sql.Date last,java.sql.Date current,int id){
	for(int i=0;i<leave.size();i++){
		Leave obj = leave.get(i);
		java.sql.Date start = removeTime(obj.getStart());
		java.sql.Date end = removeTime(obj.getEnd());
		last = removeTime(last);
		current = removeTime(current);
		if(obj.getID() == id && last.compareTo(start) == 0){
			System.out.println(id+" "+last+" "+obj.getReason());
			mergedata.put(Integer.toString(index), new Object[] {id,last,obj.getReason()});
			add(id,last.toString(),obj.getReason());
			index = index + 1;
			boolean flag = true;
			while(flag){
				last = removeTime(createDate(last));
				if(last.compareTo(current) != 0){
					System.out.println(id+" "+last+" "+obj.getReason());
					mergedata.put(Integer.toString(index), new Object[] {id,last,obj.getReason()});
					add(id,last.toString(),obj.getReason());
					index = index + 1;
				}else{
					flag = false;
				}
			}
		}
	}
}
public static java.sql.Date removeTime(java.sql.Date date) {  
	Calendar cal = Calendar.getInstance();  
    cal.setTime(date);  
    cal.set(Calendar.HOUR_OF_DAY, 0);  
    cal.set(Calendar.MINUTE, 0);  
    cal.set(Calendar.SECOND, 0);  
    cal.set(Calendar.MILLISECOND, 0);  
	return new java.sql.Date(cal.getTime().getTime()); 
}
public static  int days(java.sql.Date d1,java.sql.Date d2){
	return (int)( (d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
}
public static  java.sql.Date createDate(java.sql.Date d1){
	long time = d1.getTime() + (1000 * 60 * 60 * 24);
	return new java.sql.Date(time);
}
public static  java.sql.Date deduct(java.sql.Date d1){
	long time = d1.getTime() - (1000 * 60 * 60 * 24);
	return new java.sql.Date(time);
}
public static void save(String path){
	XSSFWorkbook workbook = new XSSFWorkbook(); 
	XSSFSheet sheet = workbook.createSheet("Employee Data");
	CreationHelper createHelper = workbook.getCreationHelper();
	CellStyle cellStyle = workbook.createCellStyle();
    cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));
	Set<String> keyset = mergedata.keySet();
	int rownum = 0;
	for(String key : keyset){
		Row row = sheet.createRow(rownum++);
		Object [] objArr = mergedata.get(key);
		int cellnum = 0;
		for(Object obj : objArr){
			Cell cell = row.createCell(cellnum++);
			if(obj instanceof java.sql.Date){
				cell.setCellValue((java.sql.Date)obj);
				cell.setCellStyle(cellStyle);
			}
			else if(obj instanceof String){
				cell.setCellValue((String)obj);
			}
			else if(obj instanceof Integer){
				cell.setCellValue((Integer)obj);
			}
		}
	}
	try{
		FileOutputStream out = new FileOutputStream(new File(path));
		workbook.write(out);
		out.close();
	}catch(Exception e){
		e.printStackTrace();
	}	
}
public static void add(int id,String dd,String reason){
	String ids = Integer.toString(id);
	if(reason.trim().length() == 0)
		reason = "-";
	if(empdata.containsKey(ids)){
		empdata.get(ids).add(dd+","+reason);
	}else{
		ArrayList<String> al = new ArrayList<String>();
		al.add(dd+","+reason);
		empdata.put(ids,al);
	}
}
}