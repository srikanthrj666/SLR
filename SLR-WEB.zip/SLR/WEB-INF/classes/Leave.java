package com;
import java.sql.Date;
public class Leave{
	int id;
	String reason;
	Date start,end;
	String status;
public void setStatus(String status){
	this.status = status;
}
public String getStatus(){
	return status;
}
public void setID(int id){
	this.id = id;
}
public int getID(){
	return id;
}
public void setReason(String reason){
	this.reason = reason;
}
public String getReason(){
	return reason;
}
public void setStart(Date start){
	this.start = start;
}
public Date getStart(){
	return start;
}
public void setEnd(Date end){
	this.end = end;
}
public Date getEnd(){
	return end;
}
}