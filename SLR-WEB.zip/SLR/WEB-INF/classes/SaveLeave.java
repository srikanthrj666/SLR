package com;
import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import java.util.Map;
import java.util.Set;
import java.util.LinkedHashMap;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.util.Calendar;
public class SaveLeave{
	static Map<String, Object[]> mergedata = new LinkedHashMap<String, Object[]>();
	static int index;
public static String confirm(File files,String array[],String option)throws Exception{
	index = 1;
	mergedata.clear();
	FileInputStream file = new FileInputStream(files);
	XSSFWorkbook workbook = new XSSFWorkbook(file);
	XSSFSheet sheet = workbook.getSheetAt(0);
	Iterator<Row> rowIterator = sheet.iterator();
	while(rowIterator.hasNext()){
		Row row = rowIterator.next();
		Iterator<Cell> cellIterator = row.cellIterator();
		Object arr[] = new Object[6];
		boolean flag = false;
		while(cellIterator.hasNext()){
			Cell cell = cellIterator.next();
			switch(cell.getCellType()){
				case Cell.CELL_TYPE_NUMERIC:{
					if(HSSFDateUtil.isCellDateFormatted(cell)){
						double dv = cell.getNumericCellValue();
						if(cell.getColumnIndex() == 2){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[2] = dd;
						}
						if(cell.getColumnIndex() == 3){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[3] = dd;
						}
						if(cell.getColumnIndex() == 4){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[4] = dd;
						}
					}else{
						int eid = (int)cell.getNumericCellValue();
						if(cell.getColumnIndex() == 0){
							if(eid != 0){
								arr[0] = eid;
								flag = true;
							}
						}
					}
					break;
				}
				case Cell.CELL_TYPE_STRING:{
					if(cell.getColumnIndex() == 1){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[1] = str;
					}
					if(cell.getColumnIndex() == 5){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[5] = str;
					}
					break;
				}
			}
		}
		if(flag){
			int ids = ((Integer)arr[0]).intValue();
			java.sql.Date request1 = (java.sql.Date)arr[3];
			request1 = removeTime(request1);
			java.sql.Date request2 = (java.sql.Date)arr[4];
			request2 = removeTime(request2);
			java.sql.Date sdate = java.sql.Date.valueOf(array[2]);
			sdate = removeTime(sdate);
			java.sql.Date edate = java.sql.Date.valueOf(array[3]);
			edate = removeTime(edate);
			String reason = (String)arr[1];
			if(ids == Integer.parseInt(array[0]) && sdate.compareTo(request1) == 0 && edate.compareTo(request2) == 0 && reason.equals(array[1])){
				arr[5] = option;
				mergedata.put(Integer.toString(index),arr);
				index = index + 1;
			}else{
				mergedata.put(Integer.toString(index),arr);
				index = index + 1;
			}
		}
	}
	file.close();
	return save(files);
}
public static String leave(File files,String id,String reason,String start,String end)throws Exception{
	System.out.println("exists "+files.exists());
	if(files.exists()){
		index = 1;
		mergedata.clear();
		FileInputStream file = new FileInputStream(files);
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();
		while(rowIterator.hasNext()){
			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			Object arr[] = new Object[6];
			boolean flag = false;
			while(cellIterator.hasNext()){
				Cell cell = cellIterator.next();
				switch(cell.getCellType()){
					case Cell.CELL_TYPE_NUMERIC:{
						if(HSSFDateUtil.isCellDateFormatted(cell)){
							double dv = cell.getNumericCellValue();
							if(cell.getColumnIndex() == 2){
								java.util.Date date = HSSFDateUtil.getJavaDate(dv);
								java.sql.Date dd = new java.sql.Date(date.getTime());
								arr[2] = dd;
							}
							if(cell.getColumnIndex() == 3){
								java.util.Date date = HSSFDateUtil.getJavaDate(dv);
								java.sql.Date dd = new java.sql.Date(date.getTime());
								arr[3] = dd;
							}
							if(cell.getColumnIndex() == 4){
								java.util.Date date = HSSFDateUtil.getJavaDate(dv);
								java.sql.Date dd = new java.sql.Date(date.getTime());
								arr[4] = dd;
							}
						}else{
							int eid = (int)cell.getNumericCellValue();
							if(cell.getColumnIndex() == 0){
								if(eid != 0){
									arr[0] = eid;
									flag = true;
								}
							}
						}
						break;
					}
					case Cell.CELL_TYPE_STRING:{
						if(cell.getColumnIndex() == 1){
							String str = cell.getStringCellValue();
							if(str.length() > 0)
								arr[1] = str;
						}
						if(cell.getColumnIndex() == 5){
							String str = cell.getStringCellValue();
							if(str.length() > 0)
								arr[5] = str;
						}
						break;
					}
				}
			}
			if(flag){
				mergedata.put(Integer.toString(index),arr);
				index = index + 1;
			}
		}
		file.close();
		java.util.Date d1 = new java.util.Date();
		java.sql.Date d2 = new java.sql.Date(d1.getTime());
		Object arr[] = new Object[6];
		arr[0] = new Integer(id);
		arr[1] = reason;
		arr[2] = d2;
		arr[3] = java.sql.Date.valueOf(start);
		arr[4] = java.sql.Date.valueOf(end);
		arr[5] = "Pending";
		mergedata.put(Integer.toString(index),arr);
	}else{
		java.util.Date d1 = new java.util.Date();
		java.sql.Date d2 = new java.sql.Date(d1.getTime());
		Object arr[] = new Object[6];
		arr[0] = new Integer(id);
		arr[1] = reason;
		arr[2] = d2;
		arr[3] = java.sql.Date.valueOf(start);
		arr[4] = java.sql.Date.valueOf(end);
		arr[5] = "Pending";
		mergedata.put("1",arr);
	}
	return save(files);
}
public static String save(File file)throws Exception{
	String msg = "fail";
	XSSFWorkbook workbook = new XSSFWorkbook(); 
	XSSFSheet sheet = workbook.createSheet("Employee Data");
	CreationHelper createHelper = workbook.getCreationHelper();
	CellStyle cellStyle = workbook.createCellStyle();
    cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));
	Set<String> keyset = mergedata.keySet();
	int rownum = 0;
	for(String key : keyset){
		Row row = sheet.createRow(rownum++);
		Object [] objArr = mergedata.get(key);
		int cellnum = 0;
		for(Object obj : objArr){
			Cell cell = row.createCell(cellnum++);
			if(obj instanceof java.util.Date){
				cell.setCellValue((java.sql.Date)obj);
				cell.setCellStyle(cellStyle);
			}
			else if(obj instanceof String){
				cell.setCellValue((String)obj);
			}
			else if(obj instanceof Integer){
				cell.setCellValue((Integer)obj);
			}
		}
	}
	FileOutputStream out = new FileOutputStream(file);
	workbook.write(out);
	out.close();
	msg = "success";
	return msg;
}
public static String cancelLeave(File files,String emp_id,String cancel_date)throws Exception{
	index = 1;
	mergedata.clear();
	FileInputStream file = new FileInputStream(files);
	XSSFWorkbook workbook = new XSSFWorkbook(file);
	XSSFSheet sheet = workbook.getSheetAt(0);
	Iterator<Row> rowIterator = sheet.iterator();
	while(rowIterator.hasNext()){
		Row row = rowIterator.next();
		Iterator<Cell> cellIterator = row.cellIterator();
		Object arr[] = new Object[6];
		boolean flag = false;
		while(cellIterator.hasNext()){
			Cell cell = cellIterator.next();
			switch(cell.getCellType()){
				case Cell.CELL_TYPE_NUMERIC:{
					if(HSSFDateUtil.isCellDateFormatted(cell)){
						double dv = cell.getNumericCellValue();
						if(cell.getColumnIndex() == 2){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[2] = dd;
						}
						if(cell.getColumnIndex() == 3){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[3] = dd;
						}
						if(cell.getColumnIndex() == 4){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[4] = dd;
						}
					}else{
						int eid = (int)cell.getNumericCellValue();
						if(cell.getColumnIndex() == 0){
							if(eid != 0){
								arr[0] = eid;
								flag = true;
							}
						}
					}
					break;
				}
				case Cell.CELL_TYPE_STRING:{
					if(cell.getColumnIndex() == 1){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[1] = str;
					}
					if(cell.getColumnIndex() == 5){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[5] = str;
					}
					break;
				}
			}
		}
		if(flag){
			int ids = ((Integer)arr[0]).intValue();
			java.sql.Date request = (java.sql.Date)arr[2];
			request = removeTime(request);
			java.util.Date udate = new java.util.Date(cancel_date.trim());
			java.sql.Date sdate = new java.sql.Date(udate.getTime());
			sdate = removeTime(sdate);
			if(ids == Integer.parseInt(emp_id) && sdate.compareTo(request) == 0){
				System.out.println(ids+" cancelled");
			}else{
				mergedata.put(Integer.toString(index),arr);
				index = index + 1;
			}
		}
	}
	file.close();
	return save(files);
}
public static java.sql.Date removeTime(java.sql.Date date) {  
	Calendar cal = Calendar.getInstance();  
    cal.setTime(date);  
    cal.set(Calendar.HOUR_OF_DAY, 0);  
    cal.set(Calendar.MINUTE, 0);  
    cal.set(Calendar.SECOND, 0);  
    cal.set(Calendar.MILLISECOND, 0);  
	return new java.sql.Date(cal.getTime().getTime()); 
}

public static String leaveStatus(File files,String emp_id,String applied_date)throws Exception{
	String msg = "Unable to find record";
	FileInputStream file = new FileInputStream(files);
	XSSFWorkbook workbook = new XSSFWorkbook(file);
	XSSFSheet sheet = workbook.getSheetAt(0);
	Iterator<Row> rowIterator = sheet.iterator();
	boolean exit = true;
	while(rowIterator.hasNext() && exit){
		Row row = rowIterator.next();
		Iterator<Cell> cellIterator = row.cellIterator();
		Object arr[] = new Object[6];
		boolean flag = false;
		while(cellIterator.hasNext()){
			Cell cell = cellIterator.next();
			switch(cell.getCellType()){
				case Cell.CELL_TYPE_NUMERIC:{
					if(HSSFDateUtil.isCellDateFormatted(cell)){
						double dv = cell.getNumericCellValue();
						if(cell.getColumnIndex() == 2){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[2] = dd;
						}
						if(cell.getColumnIndex() == 3){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[3] = dd;
						}
						if(cell.getColumnIndex() == 4){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[4] = dd;
						}
					}else{
						int eid = (int)cell.getNumericCellValue();
						if(cell.getColumnIndex() == 0){
							if(eid != 0){
								arr[0] = eid;
								flag = true;
							}
						}
					}
					break;
				}
				case Cell.CELL_TYPE_STRING:{
					if(cell.getColumnIndex() == 1){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[1] = str;
					}
					if(cell.getColumnIndex() == 5){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[5] = str;
					}
					break;
				}
			}
		}
		if(flag){
			int ids = ((Integer)arr[0]).intValue();
			java.sql.Date request = (java.sql.Date)arr[2];
			request = removeTime(request);
			java.sql.Date sdate = java.sql.Date.valueOf(applied_date.trim());
			sdate = removeTime(sdate);
			if(ids == Integer.parseInt(emp_id) && sdate.compareTo(request) == 0){
				msg = "Your leave request is "+arr[5].toString();
				exit = false;
				break;
			}
		}
	}
	file.close();
	return msg;
}

public static String viewRequest(File files,String applied_date)throws Exception{
	StringBuilder sb = new StringBuilder();
	FileInputStream file = new FileInputStream(files);
	XSSFWorkbook workbook = new XSSFWorkbook(file);
	XSSFSheet sheet = workbook.getSheetAt(0);
	Iterator<Row> rowIterator = sheet.iterator();
	while(rowIterator.hasNext()){
		Row row = rowIterator.next();
		Iterator<Cell> cellIterator = row.cellIterator();
		Object arr[] = new Object[6];
		boolean flag = false;
		while(cellIterator.hasNext()){
			Cell cell = cellIterator.next();
			switch(cell.getCellType()){
				case Cell.CELL_TYPE_NUMERIC:{
					if(HSSFDateUtil.isCellDateFormatted(cell)){
						double dv = cell.getNumericCellValue();
						if(cell.getColumnIndex() == 2){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[2] = dd;
						}
						if(cell.getColumnIndex() == 3){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[3] = dd;
						}
						if(cell.getColumnIndex() == 4){
							java.util.Date date = HSSFDateUtil.getJavaDate(dv);
							java.sql.Date dd = new java.sql.Date(date.getTime());
							arr[4] = dd;
						}
					}else{
						int eid = (int)cell.getNumericCellValue();
						if(cell.getColumnIndex() == 0){
							if(eid != 0){
								arr[0] = eid;
								flag = true;
							}
						}
					}
					break;
				}
				case Cell.CELL_TYPE_STRING:{
					if(cell.getColumnIndex() == 1){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[1] = str;
					}
					if(cell.getColumnIndex() == 5){
						String str = cell.getStringCellValue();
						if(str.length() > 0)
							arr[5] = str;
					}
					break;
				}
			}
		}
		if(flag){
			int ids = ((Integer)arr[0]).intValue();
			java.sql.Date request = (java.sql.Date)arr[2];
			request = removeTime(request);
			java.sql.Date sdate = java.sql.Date.valueOf(applied_date.trim());
			sdate = removeTime(sdate);
			String reason = (String)arr[1];
			java.sql.Date start = (java.sql.Date)arr[3];
			java.sql.Date end = (java.sql.Date)arr[4];
			String status_data = (String)arr[5];
			if(status_data.equals("Pending") && sdate.compareTo(request) == 0){
				sb.append(ids+","+reason+","+start.toString()+","+end.toString()+"#");
			}
		}
	}
	file.close();
	if(sb.length() > 0)
		sb.deleteCharAt(sb.length()-1);
	if(sb.length() == 0)
		sb.append("none");
	return sb.toString();
}
}