package com;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
public class Salary extends HttpServlet {
public void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
	try{
		String id = request.getParameter("t1").trim();
		double salary = DBCon.getSalary(id);
		double count = 0;
		StringBuilder sb = new StringBuilder();
		HashMap<String,ArrayList<String>> empdata = CalculateLeave.empdata;
		for(Map.Entry<String,ArrayList<String>> me : empdata.entrySet()){
			String eid = me.getKey();
			if(id.equals(eid)){
				ArrayList<String> list = me.getValue();
				for(int i=0;i<list.size();i++){
					String arr[] = list.get(i).split(",");
					sb.append(id+","+arr[0]+","+arr[1]+"#");
					if(arr[1].equals("-"))
						count = count + 1;
				}
			}
		}
		double per = salary / 30;
		double sal = per * count;
		sb.append("Total Days : 30,Working Days : "+count+",Total Salary : "+salary+" Net Pay : "+sal);
		HttpSession session=request.getSession();
		session.setAttribute("data1",sb.toString());
		RequestDispatcher rd=request.getRequestDispatcher("ViewSalary.jsp");
		rd.forward(request, response);
	}catch(Exception e){
		e.printStackTrace();
	}
}

}
