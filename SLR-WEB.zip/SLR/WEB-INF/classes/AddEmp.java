package com;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class AddEmp extends HttpServlet {
public void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
	String id=request.getParameter("t9").trim();
	String name=request.getParameter("t1").trim();
	String gender=request.getParameter("t2").trim();
	String type=request.getParameter("t3").trim();
	String contact=request.getParameter("t4").trim();
	String email=request.getParameter("t5").trim();
	String address=request.getParameter("t6").trim();
	String user=request.getParameter("t7").trim();
	String password=request.getParameter("t8").trim();
	String salary=request.getParameter("t10").trim();
	try{
		String input[]={id,name,gender,type,contact,email,address,salary,user,password};
		String res = DBCon.empRegister(input);
		if(res.equals("success")){
			RequestDispatcher rd=request.getRequestDispatcher("AdminScreen.jsp?t1="+user+" registration process completed");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd=request.getRequestDispatcher("AdminScreen.jsp?t1=Error in registration");
			rd.forward(request, response);
		}
		
	}catch(Exception e){
		e.printStackTrace();
	}
}

}
