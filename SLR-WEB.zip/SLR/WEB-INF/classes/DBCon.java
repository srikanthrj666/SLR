package com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.sql.Statement;
import java.util.ArrayList;
import java.io.FileWriter;
public class DBCon{
    private static Connection con;
public static Connection getCon()throws Exception {
   try{
		 Class.forName("com.mysql.jdbc.Driver");
		 con = DriverManager.getConnection("jdbc:mysql://localhost/slr","root","root");
     
	}catch(Exception e){
		e.printStackTrace();
	}
	return con;
}
public static String empRegister(String[] input)throws Exception{
    String msg="no";
    boolean flag=false;
    con = getCon();
	Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select username from addemp where username='"+input[6]+"'");
    if(rs.next()){
        flag=true;
        msg = "Username already exist";
    }
    if(!flag){
		PreparedStatement stat=con.prepareStatement("insert into addemp values(?,?,?,?,?,?,?,?,?,?)");
		stat.setString(1,input[0]);
		stat.setString(2,input[1]);
		stat.setString(3,input[2]);
		stat.setString(4,input[3]);
		stat.setString(5,input[4]);
		stat.setString(6,input[5]);
		stat.setString(7,input[6]);
		stat.setDouble(8,Double.parseDouble(input[7]));
		stat.setString(9,input[8]);
		stat.setString(10,input[9]);
		int i=stat.executeUpdate();
		if(i > 0){
			msg = "success";
		}
    }
    return msg;
}
public static String login(String input[])throws Exception{
    String msg="invalid";
	con = getCon();
    Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select usertype from addemp where username='"+input[0]+"' and password='"+input[1]+"' and usertype='Accountant'");
	while(rs.next()){
		msg = "success";
	}
    return msg;
}
public static String userLogin(String user,String pass)throws Exception{
    String msg="invalid";
	con = getCon();
    Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select usertype from addemp where username='"+user+"' and password='"+pass+"'");
	while(rs.next()){
		msg = rs.getString(1);
	}
    return msg;
}
public static String getID(String user)throws Exception{
    String msg="invalid";
	con = getCon();
    Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select emp_id from addemp where username='"+user+"'");
	while(rs.next()){
		msg = rs.getString(1);
	}
    return msg;
}
public static double getSalary(String id)throws Exception{
    double salary = 0;
	con = getCon();
    Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select salary from addemp where emp_id='"+id+"'");
	while(rs.next()){
		salary = rs.getDouble(1);
	}
    return salary;
}
public static int[] getEid()throws Exception{
    StringBuilder sb = new StringBuilder();
	con = getCon();
    Statement stmt=con.createStatement();
    ResultSet rs=stmt.executeQuery("select emp_id from addemp");
	while(rs.next()){
		sb.append(rs.getString(1)+",");
	}
	if(sb.length() > 0)
		sb.deleteCharAt(sb.length()-1);
	String str[] = sb.toString().split(",");
	int arr[] = new int[str.length];
	for(int i=0;i<str.length;i++){
		arr[i] = Integer.parseInt(str[i].trim());
	}
    return arr;
}
}
