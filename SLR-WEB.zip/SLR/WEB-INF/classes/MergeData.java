package com;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
public class MergeData extends HttpServlet {
public void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
	try{
		String dataset = getServletContext().getRealPath("/")+"WEB-INF/classes/dataset";
		String leave = getServletContext().getRealPath("/")+"WEB-INF/leave.xlsx";
		String merge = getServletContext().getRealPath("/")+"WEB-INF/merge.xlsx";
		CalculateLeave.readLeaveExcel(leave);
		CalculateLeave.readAttendedExcel(dataset);
		CalculateLeave.save(merge);
		StringBuilder sb = new StringBuilder();
		HashMap<String,ArrayList<String>> empdata = CalculateLeave.empdata;
		for(Map.Entry<String,ArrayList<String>> me : empdata.entrySet()){
			String id = me.getKey();
			ArrayList<String> list = me.getValue();
			for(int i=0;i<list.size();i++){
				String arr[] = list.get(i).split(",");
				sb.append(id+","+arr[0]+","+arr[1]+"#");
			}
		}
		if(sb.length() > 0)
			sb.deleteCharAt(sb.length()-1);
		HttpSession session=request.getSession();
		session.setAttribute("data",sb.toString());
		RequestDispatcher rd=request.getRequestDispatcher("ViewMergeData.jsp");
		rd.forward(request, response);
	}catch(Exception e){
		e.printStackTrace();
	}
}

}
